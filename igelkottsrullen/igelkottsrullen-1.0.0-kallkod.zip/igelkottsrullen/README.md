# Igelkottsrullen – tilt maze game for Ubuntu Touch

Tilt the phone and roll the hedgehog home to its den through the Swedish forest. Pick up the apples, keep away from the holes, and beat the star time.

- 12 levels in three worlds: summer forest, autumn forest (mud slows you down) and winter forest (slippery ice)
- 1–3 stars per level; the next level opens when the previous one is done
- Tilt control with the accelerometer, calibrated during the countdown before each level
- Finger control as well (drag from anywhere), and as the only control when there is no tilt sensor
- Light (day), dark (evening) or automatic theme
- English and Swedish
- Stars and best times saved locally (SQLite)
- All levels, graphics and sounds are made for this game

## Svenska

Ett labyrintspel för Ubuntu Touch. Luta telefonen och rulla hem igelkotten till lyan genom den svenska skogen. Plocka äpplena, akta dig för hålen och slå stjärntiden. Tolv banor i sommar-, höst- och vinterskogen, med lera som bromsar och is som är hal.

## Permissions

`sensors` (tilt), `audio` (sounds) and `keep-display-on` (the screen stays on while you play, since you don't touch it). All three are *common* policy groups.

## Build

```bash
clickable build
# or without clickable:
click build <dir with qml/, assets/, manifest.json, igelkottsrullen.apparmor, igelkottsrullen.desktop, LICENSE>
```

## Development

```bash
node tests/levels.test.js     # every level is well formed, and a computer player clears it with all apples
node tests/i18n.test.js       # every text has a Swedish translation
python3 tools/make_art.py     # regenerates the SVG graphics
python3 tools/make_sounds.py  # regenerates the sound effects (numpy, scipy)
GRID_UNIT_PX=16 UITK_ICON_THEME=suru qmlscene qml/Main.qml --page=game --level=3 --autoplay
```

Test flags: `--demo`, `--autoplay`, `--level=<1–12>`, `--page=game|levels|settings`, `--control=tilt|touch`, `--lang=sv|en`, `--theme=light|dark`, `--mute`.

Levels are plain text in `qml/Levels.js` (10 × 16 squares): `#` wall, `.` ground, `o` hole, `a` apple, `S` start, `G` den, `~` mud, `=` ice.

The background sounds come from [Kottslungan](https://github.com/finnjohan/kottslungan) by the same author.

## License

GPL-3.0-or-later © 2026 Johan Finn
