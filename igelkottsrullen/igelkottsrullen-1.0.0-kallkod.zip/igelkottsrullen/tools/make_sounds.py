#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Skapar spelets ljudeffekter från grunden med numpy (inga inspelningar, inga
# lånade ljud). Kör: python3 tools/make_sounds.py   (kräver numpy och scipy)
# Bakgrundsljuden (ambience-*.ogg) kommer från Kottslungan, samma upphovsperson.
import os
import wave

import numpy as np
from scipy.signal import butter, sosfilt

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "sounds")
rng = np.random.default_rng(2026)


def t_of(sec):
    return np.arange(int(sec * SR)) / SR


def band(x, lo, hi):
    return sosfilt(butter(2, [lo, hi], "band", fs=SR, output="sos"), x)


def low(x, f):
    return sosfilt(butter(2, f, "low", fs=SR, output="sos"), x)


def place(buf, clip, at):
    i = int(at * SR)
    n = min(len(clip), len(buf) - i)
    buf[i:i + n] += clip[:n]


def bell(freqs, step, sec, decay=7, amp=0.6):
    out = np.zeros(int(sec * SR))
    for i, f in enumerate(freqs):
        tt = t_of(0.7)
        note = (np.sin(2 * np.pi * f * tt) + 0.3 * np.sin(2 * np.pi * 2 * f * tt) * np.exp(-tt * 12)) * np.exp(-tt * decay)
        place(out, note * amp, i * step)
    return out


def sfx_apple():         # ett krispigt tugg och en liten klang
    t = t_of(0.4)
    crunch = band(rng.normal(size=len(t)), 1500, 5000) * np.exp(-t * 40) * (1 + 0.8 * np.sin(2 * np.pi * 60 * t))
    return 0.5 * crunch + bell([880, 1318.5], 0.06, 0.4, decay=9, amp=0.45)


def sfx_bump():          # duns mot häcken eller stenen
    t = t_of(0.18)
    thud = np.sin(2 * np.pi * 110 * t * (1 - 1.5 * t)) * np.exp(-t * 28)
    rustle = band(rng.normal(size=len(t)), 300, 2200) * np.exp(-t * 35)
    return 0.8 * thud + 0.35 * rustle


def sfx_fall():          # tonen sjunker när igelkotten rullar ner i hålet
    t = t_of(0.75)
    f = np.geomspace(900, 160, len(t))
    tone = np.sin(2 * np.pi * np.cumsum(f) / SR) * (1 - t / 0.75) ** 1.2
    plop = np.zeros(len(t))
    tt = t_of(0.2)
    place(plop, np.sin(2 * np.pi * 90 * tt) * np.exp(-tt * 20), 0.55)
    return 0.45 * tone + 0.6 * plop


def sfx_win():           # liten fanfar när igelkotten når lyan
    return bell([523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5], 0.11, 1.4, decay=5, amp=0.5)


def sfx_tick():          # nedräkning 3, 2, 1
    t = t_of(0.12)
    return 0.5 * np.sin(2 * np.pi * 660 * t) * np.exp(-t * 30)


def sfx_go():
    t = t_of(0.3)
    return 0.5 * (np.sin(2 * np.pi * 990 * t) + 0.3 * np.sin(2 * np.pi * 1980 * t)) * np.exp(-t * 12)


def sfx_star():
    return bell([1318.5, 1760], 0.05, 0.5, decay=10, amp=0.4)


def write(name, x):
    x = np.asarray(x, dtype=float)
    peak = np.max(np.abs(x)) or 1
    x = x / peak * 0.85
    fade = min(len(x), int(0.01 * SR))
    x[-fade:] *= np.linspace(1, 0, fade)
    data = (x * 32767).astype("<i2")
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


os.makedirs(OUT, exist_ok=True)
for name, fn in [("apple", sfx_apple), ("bump", sfx_bump), ("fall", sfx_fall), ("win", sfx_win),
                 ("tick", sfx_tick), ("go", sfx_go), ("star", sfx_star)]:
    write(name, fn())
print("klart:", sorted(os.listdir(OUT)))
