#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Johan Finn
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Skriver all grafik till assets/ som SVG. Allt är ritat för det här spelet.
# Kör: python3 tools/make_art.py
import math
import os
import random

OUT = os.path.join(os.path.dirname(__file__), "..", "assets")
os.makedirs(OUT, exist_ok=True)


def save(name, w, h, body):
    with open(os.path.join(OUT, name), "w") as f:
        f.write(f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">\n{body}\n</svg>\n')


def spikes(cx, cy, r, n, length, color, rnd, jitter=0.0):
    out = []
    for i in range(n):
        a = 2 * math.pi * i / n + rnd.uniform(-jitter, jitter)
        w = math.pi / n * 1.25
        l = length * rnd.uniform(0.8, 1.1)
        p1 = (cx + r * math.cos(a - w), cy + r * math.sin(a - w))
        p2 = (cx + (r + l) * math.cos(a), cy + (r + l) * math.sin(a))
        p3 = (cx + r * math.cos(a + w), cy + r * math.sin(a + w))
        out.append(f'<polygon points="{p1[0]:.1f},{p1[1]:.1f} {p2[0]:.1f},{p2[1]:.1f} {p3[0]:.1f},{p3[1]:.1f}" fill="{color}"/>')
    return "\n".join(out)


# ---- Igelkotten, sedd uppifrån, ihoprullad. Nosen pekar åt höger (0°). ----
def hedgehog():
    rnd = random.Random(3)
    b = []
    b.append('<defs><radialGradient id="body" cx="0.42" cy="0.4" r="0.65">'
             '<stop offset="0" stop-color="#A9784A"/><stop offset="1" stop-color="#5E3B1E"/></radialGradient></defs>')
    b.append('<ellipse cx="66" cy="70" rx="50" ry="48" fill="#000" opacity="0.22"/>')
    b.append(spikes(64, 64, 40, 34, 18, "#4A2E16", rnd, 0.04))
    b.append(spikes(64, 64, 38, 34, 13, "#7A5230", rnd, 0.06))
    b.append('<circle cx="64" cy="64" r="42" fill="url(#body)"/>')
    # Taggar på ryggen som små streck
    for i in range(46):
        a = rnd.uniform(0, 2 * math.pi)
        rr = rnd.uniform(6, 36)
        x, y = 64 + rr * math.cos(a), 64 + rr * math.sin(a)
        d = math.atan2(y - 64, x - 64)
        x2, y2 = x + 7 * math.cos(d), y + 7 * math.sin(d)
        b.append(f'<line x1="{x:.1f}" y1="{y:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="#3D2412" stroke-width="2.4" stroke-linecap="round" opacity="0.75"/>')
        b.append(f'<line x1="{x:.1f}" y1="{y:.1f}" x2="{(x + x2) / 2:.1f}" y2="{(y + y2) / 2:.1f}" stroke="#E8D2B0" stroke-width="1.6" stroke-linecap="round" opacity="0.8"/>')
    # Ansiktet tittar fram åt höger
    b.append('<ellipse cx="96" cy="64" rx="20" ry="17" fill="#E9C99A"/>')
    b.append('<ellipse cx="112" cy="64" rx="9" ry="7" fill="#E9C99A"/>')
    b.append('<circle cx="121" cy="64" r="5" fill="#2A1A10"/>')
    b.append('<circle cx="122.5" cy="62.5" r="1.6" fill="#FFFFFF" opacity="0.8"/>')
    b.append('<circle cx="100" cy="55" r="3.6" fill="#1A1008"/><circle cx="101" cy="54" r="1.2" fill="#FFF"/>')
    b.append('<circle cx="100" cy="73" r="3.6" fill="#1A1008"/><circle cx="101" cy="72" r="1.2" fill="#FFF"/>')
    b.append('<ellipse cx="88" cy="48" rx="5" ry="4" fill="#C9A27A"/><ellipse cx="88" cy="80" rx="5" ry="4" fill="#C9A27A"/>')
    save("hedgehog.svg", 128, 128, "\n".join(b))


def apple():
    b = ['<defs><radialGradient id="a" cx="0.38" cy="0.35" r="0.7">'
         '<stop offset="0" stop-color="#FF7A6B"/><stop offset="0.55" stop-color="#E0302A"/><stop offset="1" stop-color="#9C1A16"/></radialGradient></defs>',
         '<ellipse cx="66" cy="74" rx="42" ry="40" fill="#000" opacity="0.2"/>',
         '<path d="M64 34 C 40 22, 16 38, 20 66 C 24 96, 46 112, 64 104 C 82 112, 104 96, 108 66 C 112 38, 88 22, 64 34 Z" fill="url(#a)"/>',
         '<ellipse cx="46" cy="52" rx="9" ry="14" fill="#FFFFFF" opacity="0.35" transform="rotate(-25 46 52)"/>',
         '<path d="M64 36 C 63 26, 66 18, 70 12" stroke="#5A3A1A" stroke-width="5" fill="none" stroke-linecap="round"/>',
         '<path d="M68 22 C 80 8, 100 12, 104 20 C 92 30, 78 30, 68 22 Z" fill="#5BAE3C"/>',
         '<path d="M70 21 C 82 18, 92 18, 102 20" stroke="#3E8A28" stroke-width="2" fill="none"/>']
    save("apple.svg", 128, 128, "\n".join(b))


def hole():
    b = ['<defs><radialGradient id="h" cx="0.5" cy="0.55" r="0.5">'
         '<stop offset="0" stop-color="#050302"/><stop offset="0.7" stop-color="#1A0F08"/><stop offset="0.86" stop-color="#3A2614"/>'
         '<stop offset="1" stop-color="#6B4A2A" stop-opacity="0"/></radialGradient></defs>',
         '<circle cx="64" cy="64" r="62" fill="url(#h)"/>',
         '<path d="M22 50 A 46 46 0 0 1 106 50" stroke="#2A1A0C" stroke-width="5" fill="none" opacity="0.6"/>']
    rnd = random.Random(7)
    for i in range(14):
        a = rnd.uniform(0, 2 * math.pi)
        r = rnd.uniform(48, 56)
        b.append(f'<circle cx="{64 + r * math.cos(a):.1f}" cy="{64 + r * math.sin(a):.1f}" r="{rnd.uniform(2, 4):.1f}" fill="#7B5634" opacity="0.8"/>')
    save("hole.svg", 128, 128, "\n".join(b))


def goal():
    # Lyan: en håla under en rot, med löv och mossa runt
    b = ['<defs><radialGradient id="g" cx="0.5" cy="0.6" r="0.5">'
         '<stop offset="0" stop-color="#0A0604"/><stop offset="0.8" stop-color="#2B1A0E"/><stop offset="1" stop-color="#4A321C"/></radialGradient></defs>',
         '<ellipse cx="64" cy="70" rx="58" ry="52" fill="#000" opacity="0.18"/>',
         '<ellipse cx="64" cy="66" rx="56" ry="50" fill="#7A9A3A"/>',
         '<ellipse cx="64" cy="66" rx="48" ry="42" fill="#5E7E2A"/>',
         '<ellipse cx="64" cy="72" rx="34" ry="30" fill="url(#g)"/>',
         '<path d="M14 40 C 34 22, 56 30, 64 34 C 74 26, 98 20, 116 38" stroke="#6B4423" stroke-width="12" fill="none" stroke-linecap="round"/>',
         '<path d="M18 40 C 36 26, 56 34, 64 37" stroke="#8B5E34" stroke-width="4" fill="none" stroke-linecap="round"/>']
    rnd = random.Random(11)
    cols = ["#D9822B", "#C0392B", "#E6B33A", "#8E5A2B"]
    for i in range(9):
        a = rnd.uniform(0.2, math.pi - 0.2) + math.pi * (i % 2)
        r = rnd.uniform(44, 54)
        x, y = 64 + r * math.cos(a), 66 + r * 0.9 * math.sin(a)
        rot = rnd.uniform(0, 360)
        b.append(f'<ellipse cx="{x:.1f}" cy="{y:.1f}" rx="8" ry="4.5" fill="{cols[i % 4]}" transform="rotate({rot:.0f} {x:.1f} {y:.1f})"/>')
    save("goal.svg", 128, 128, "\n".join(b))


# ---- Rutor (64×64) ----------------------------------------------------------
def tile(name, base, dots, seed, extra=""):
    rnd = random.Random(seed)
    b = [f'<rect width="64" height="64" fill="{base}"/>']
    for color, n, rmin, rmax, op in dots:
        for i in range(n):
            x, y = rnd.uniform(4, 60), rnd.uniform(4, 60)
            b.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rnd.uniform(rmin, rmax):.1f}" fill="{color}" opacity="{op}"/>')
    b.append(extra)
    save(name, 64, 64, "\n".join(b))


def grass_blades(seed, colors, n):
    rnd = random.Random(seed)
    out = []
    for i in range(n):
        x, y = rnd.uniform(3, 61), rnd.uniform(6, 62)
        h = rnd.uniform(4, 8)
        c = rnd.choice(colors)
        out.append(f'<path d="M{x:.1f} {y:.1f} l{rnd.uniform(-2, 2):.1f} {-h:.1f}" stroke="{c}" stroke-width="1.6" stroke-linecap="round"/>')
    return "\n".join(out)


def leaves(seed, n):
    rnd = random.Random(seed)
    cols = ["#C8641E", "#D99A2B", "#A63A1E", "#E0B840", "#8A4A1E"]
    out = []
    for i in range(n):
        x, y = rnd.uniform(6, 58), rnd.uniform(6, 58)
        rot = rnd.uniform(0, 360)
        out.append(f'<ellipse cx="{x:.1f}" cy="{y:.1f}" rx="{rnd.uniform(3.5, 5.5):.1f}" ry="2.4" fill="{rnd.choice(cols)}" opacity="0.9" transform="rotate({rot:.0f} {x:.1f} {y:.1f})"/>')
    return "\n".join(out)


def tiles():
    tile("floor-summer.svg", "#6DA544", [("#5C9638", 18, 2, 5, 0.6), ("#86BC58", 12, 1.5, 3, 0.6)], 1,
         grass_blades(2, ["#4E8A2E", "#8CC560"], 22) +
         '<circle cx="20" cy="44" r="2" fill="#FFFFFF"/><circle cx="20" cy="44" r="0.9" fill="#F4C430"/>')
    tile("floor-autumn.svg", "#8A8A3E", [("#75763A", 16, 2, 5, 0.6), ("#9C9A4E", 10, 1.5, 3, 0.6)], 3, leaves(4, 5))
    tile("floor-winter.svg", "#D6E2EC", [("#C6D4E2", 14, 3, 7, 0.8), ("#EEF4FA", 10, 1.5, 3, 0.9)], 5)
    tile("mud.svg", "#6B4A2E", [("#5A3C24", 14, 3, 7, 0.7), ("#82603E", 8, 2, 4, 0.6)], 6,
         '<ellipse cx="38" cy="26" rx="10" ry="5" fill="#9AB0C0" opacity="0.35"/>'
         '<ellipse cx="18" cy="48" rx="7" ry="3.5" fill="#9AB0C0" opacity="0.3"/>')
    tile("ice.svg", "#BFE3F5", [("#D8F0FC", 6, 4, 9, 0.7)], 8,
         '<path d="M6 50 L 26 30 M 34 58 L 58 34 M 12 18 L 22 8" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round" opacity="0.8"/>'
         '<path d="M40 14 L 46 22 L 52 18" stroke="#8CC4E0" stroke-width="1.2" fill="none" opacity="0.7"/>')
    # Väggar: häck (sommar), stenmur (höst), snödriva (vinter)
    rnd = random.Random(9)
    hedge = ['<rect width="64" height="64" fill="#2F6B2A"/>']
    for i in range(26):
        x, y = rnd.uniform(4, 60), rnd.uniform(4, 60)
        hedge.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rnd.uniform(6, 10):.1f}" fill="{rnd.choice(["#3E8A34", "#357A2E", "#4A9A3C"])}"/>')
    for i in range(12):
        x, y = rnd.uniform(6, 58), rnd.uniform(6, 58)
        hedge.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rnd.uniform(2, 3.5):.1f}" fill="#6CC05A" opacity="0.7"/>')
    save("wall-summer.svg", 64, 64, "\n".join(hedge))
    stone = ['<rect width="64" height="64" fill="#5E5A54"/>']
    for (x, y, w, h) in [(2, 2, 28, 18), (32, 2, 30, 18), (2, 22, 18, 19), (22, 22, 24, 19), (48, 22, 14, 19), (2, 43, 32, 19), (36, 43, 26, 19)]:
        g = rnd.choice(["#8C877E", "#9A948A", "#7E796F", "#A39D92"])
        stone.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" fill="{g}"/>')
        stone.append(f'<rect x="{x + 3}" y="{y + 2}" width="{w - 8}" height="4" rx="2" fill="#FFFFFF" opacity="0.18"/>')
    stone.append('<circle cx="50" cy="12" r="4" fill="#7A9A3A" opacity="0.8"/><circle cx="12" cy="52" r="3" fill="#7A9A3A" opacity="0.7"/>')
    save("wall-autumn.svg", 64, 64, "\n".join(stone))
    snow = ['<rect width="64" height="64" fill="#C8D8EA"/>']
    for i in range(18):
        x, y = rnd.uniform(4, 60), rnd.uniform(4, 60)
        snow.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rnd.uniform(8, 12):.1f}" fill="{rnd.choice(["#F4F8FC", "#E6EEF8", "#FFFFFF"])}"/>')
    for i in range(6):
        x, y = rnd.uniform(8, 56), rnd.uniform(8, 56)
        snow.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2" fill="#2F6B3A" opacity="0.55"/>')
    save("wall-winter.svg", 64, 64, "\n".join(snow))


def logo():
    rnd = random.Random(3)
    b = ['<defs><linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">'
         '<stop offset="0" stop-color="#8CC560"/><stop offset="1" stop-color="#4E8A2E"/></linearGradient>'
         '<radialGradient id="body" cx="0.42" cy="0.4" r="0.65"><stop offset="0" stop-color="#A9784A"/><stop offset="1" stop-color="#5E3B1E"/></radialGradient></defs>',
         '<rect width="256" height="256" rx="48" fill="url(#bg)"/>',
         '<path d="M30 200 C 80 170, 170 210, 226 180" stroke="#3E7426" stroke-width="10" fill="none" stroke-linecap="round" opacity="0.6"/>',
         '<ellipse cx="132" cy="146" rx="80" ry="74" fill="#000" opacity="0.2"/>']
    b.append(spikes(124, 128, 62, 30, 26, "#4A2E16", rnd, 0.03))
    b.append('<circle cx="124" cy="128" r="66" fill="url(#body)"/>')
    for i in range(30):
        a = rnd.uniform(0, 2 * math.pi)
        rr = rnd.uniform(10, 56)
        x, y = 124 + rr * math.cos(a), 128 + rr * math.sin(a)
        d = math.atan2(y - 128, x - 124)
        b.append(f'<line x1="{x:.1f}" y1="{y:.1f}" x2="{x + 11 * math.cos(d):.1f}" y2="{y + 11 * math.sin(d):.1f}" stroke="#3D2412" stroke-width="4" stroke-linecap="round" opacity="0.7"/>')
    b.append('<ellipse cx="174" cy="134" rx="30" ry="26" fill="#E9C99A"/>')
    b.append('<ellipse cx="200" cy="138" rx="14" ry="11" fill="#E9C99A"/>')
    b.append('<circle cx="214" cy="138" r="8" fill="#2A1A10"/>')
    b.append('<circle cx="178" cy="122" r="6" fill="#1A1008"/><circle cx="180" cy="120" r="2" fill="#FFF"/>')
    b.append('<path d="M60 56 C 54 40, 66 30, 76 36 C 92 30, 100 44, 92 58 C 88 70, 66 70, 60 56 Z" fill="#E0302A"/>')
    b.append('<path d="M76 36 C 76 28, 80 22, 84 18" stroke="#5A3A1A" stroke-width="4" fill="none" stroke-linecap="round"/>')
    b.append('<path d="M82 24 C 90 14, 104 18, 106 22 C 98 30, 88 30, 82 24 Z" fill="#5BAE3C"/>')
    save("logo.svg", 256, 256, "\n".join(b))


hedgehog()
apple()
hole()
goal()
tiles()
logo()
print("klart:", sorted(os.listdir(OUT)))
