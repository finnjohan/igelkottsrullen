// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
// Kör: node tests/levels.test.js [bana …]
// Kontrollerar att varje bana är rätt byggd och att datorspelaren klarar den,
// både med alla äpplen och direkt till lyan. Skriver ut förslag på stjärntid.
const ctx = require("./load.js")(["Logic.js", "Levels.js"])
const L = ctx
const only = process.argv.slice(2).map(Number)
let fail = 0
for (let i = 0; i < L.levels.length; i++) {
    if (only.length && only.indexOf(i + 1) < 0) continue
    const def = L.levels[i]
    const errs = []
    if (def.map.length !== L.ROWS) errs.push(`${def.map.length} rader`)
    def.map.forEach((row, r) => { if (row.length !== L.COLS) errs.push(`rad ${r} har ${row.length} tecken`) })
    const txt = def.map.join("")
    for (const ch of ["S", "G"]) if (txt.split(ch).length !== 2) errs.push(`ska ha exakt ett ${ch}`)
    if (/[^#.oaSG~=]/.test(txt)) errs.push("okänt tecken")
    for (let c = 0; c < L.COLS; c++) if (def.map[0][c] !== "#" || def.map[L.ROWS - 1][c] !== "#") errs.push("öppen kant (topp/botten)")
    for (let r = 0; r < L.ROWS; r++) if (def.map[r][0] !== "#" || def.map[r][L.COLS - 1] !== "#") errs.push("öppen kant (sida)")
    if (errs.length) { fail++; console.log(`${i + 1} ${def.name}: FEL ${[...new Set(errs)].join(", ")}`); continue }

    const all = L.simulate(def, { apples: true, maxTime: 180 })
    const direct = L.simulate(def, { apples: false, maxTime: 180 })
    const nApples = L.parse(def).apples.length
    const ok = all.won && all.taken === nApples && all.falls === 0 && direct.won && direct.falls === 0
    if (!ok) fail++
    const par = all.won ? Math.ceil(all.time * 1.3) : 0
    console.log(`${String(i + 1).padStart(2)} ${def.name.padEnd(16)} ${def.world.padEnd(7)} ` +
        `äpplen ${all.taken}/${nApples}  tid ${all.won ? all.time.toFixed(1) : "–"} s  fall ${all.falls}  ` +
        `direkt ${direct.won ? direct.time.toFixed(1) : "–"} s (fall ${direct.falls})  ` +
        `par ${def.par} (förslag ${par})  ${ok ? "OK" : "MISSLYCKADES"}` +
        (def.par && all.won && all.time > def.par ? "  DATORN KLARAR INTE STJÄRNTIDEN" : ""))
}

// Stjärnor och fysik i små tester
const lv = L.parse(L.levels[0])
const s = L.newGame(lv)
for (let k = 0; k < 600; k++) L.step(s, 1, 0, 1 / 120)
if (s.x > L.COLS - 1 - L.BALL_R + 1e-6) { fail++; console.log("kulan gick igenom väggen", s.x) }
if (L.stars({ par: 10 }, lv, 3, 9) !== 3 || L.stars({ par: 10 }, lv, 3, 11) !== 2 || L.stars({ par: 10 }, lv, 1, 5) !== 1) { fail++; console.log("stjärnorna räknas fel") }
console.log(fail ? `${fail} fel` : "alla banor OK")
process.exit(fail ? 1 : 0)
