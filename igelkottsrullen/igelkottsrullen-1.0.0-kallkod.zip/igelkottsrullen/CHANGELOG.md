# Changelog

- 1.0.0 – First version: 12 levels in the summer, autumn and winter forest, tilt and finger control, stars and best times, light and dark theme, English and Swedish.
