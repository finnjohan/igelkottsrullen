// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

Page {
    id: page
    // Ingen rubrikrad: banan bakom menyn fyller skärmen
    header: Item { height: 0; visible: false }

    readonly property string world: demo.world
    property int demoLevel: 0

    Rectangle {
        anchors.fill: parent
        color: demo.world === "winter" ? "#5E7A94" : demo.world === "autumn" ? "#4A3A22" : "#2F5A26"
    }

    // Datorspelaren rullar genom banorna bakom menyn
    GameView {
        id: demo
        anchors.fill: parent
        alignBottom: false
        level: page.demoLevel
        autoplay: true
        night: root.isDark
        running: stack.currentPage === page
        onWon: nextTimer.start()
    }
    Timer {
        id: nextTimer
        interval: 1400
        onTriggered: page.demoLevel = (page.demoLevel + 1) % root.levelCount
    }

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0; color: "#A0000000" }
            GradientStop { position: 0.45; color: "#30000000" }
            GradientStop { position: 1; color: "#90000000" }
        }
    }

    Column {
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: parent.height * 0.1 }
        spacing: units.gu(1.2)
        Image {
            anchors.horizontalCenter: parent.horizontalCenter
            source: "../assets/hedgehog.svg"
            width: units.gu(10); height: width
            sourceSize: Qt.size(256, 256)
            NumberAnimation on rotation {
                from: 0; to: 360; duration: 6000; loops: Animation.Infinite
                running: stack.currentPage === page && Qt.application.state === Qt.ApplicationActive
            }
        }
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "Igelkottsrullen"
            font.pixelSize: Math.min(page.width * 0.12, units.gu(8))
            font.weight: Font.Bold
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            width: Math.min(implicitWidth, page.width - units.gu(4))
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: root.tr("Tilt the phone and roll the hedgehog home")
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
    }

    Column {
        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: parent.height * 0.1 }
        spacing: units.gu(1.5)
        Button {
            anchors.horizontalCenter: parent.horizontalCenter
            width: units.gu(26); height: units.gu(6)
            color: "#E8862A"
            text: root.starsFor(0) === 0 ? root.tr("Play") : root.tr("Play level %1").arg(root.nextLevel() + 1)
            onClicked: root.play(root.nextLevel())
        }
        Button {
            anchors.horizontalCenter: parent.horizontalCenter
            width: units.gu(26); height: units.gu(6)
            text: root.tr("Levels")
            onClicked: stack.push(Qt.resolvedUrl("LevelsPage.qml"))
        }
        Row {
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: units.gu(0.6)
            Icon { name: "starred"; color: "#F5B400"; width: units.gu(2.5); height: width; anchors.verticalCenter: parent.verticalCenter }
            Label {
                anchors.verticalCenter: parent.verticalCenter
                text: root.totalStars() + " / " + root.levelCount * 3
                font.weight: Font.Bold
                color: "#FFFFFF"
                style: Text.Outline; styleColor: "#3A2A10"
            }
        }
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            visible: !root.useTilt && !root.autoplay   // dold på skärmdumpar
            width: Math.min(implicitWidth, page.width - units.gu(4))
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            textSize: Label.Small
            text: root.controlSetting === "touch" ? root.tr("Touch control is on") : root.tr("No tilt sensor found – drag your finger to play")
            color: "#FFFFFF"
            style: Text.Outline; styleColor: "#3A2A10"
        }
    }

    RoundButton {
        anchors { right: parent.right; top: parent.top; margins: units.gu(1.5) }
        iconName: "settings"
        onClicked: stack.push(Qt.resolvedUrl("SettingsPage.qml"))
    }
}
