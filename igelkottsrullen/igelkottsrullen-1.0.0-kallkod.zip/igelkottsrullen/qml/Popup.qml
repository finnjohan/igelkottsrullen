// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3

// Text som stiger och tonar bort (äpplen, stjärntid). Tar bort sig själv.
Label {
    id: pop
    property real startY: 0
    font.pixelSize: units.gu(3.2)
    font.weight: Font.Bold
    color: "#FFE082"
    style: Text.Outline; styleColor: "#3A2A10"
    horizontalAlignment: Text.AlignHCenter
    y: startY
    ParallelAnimation {
        running: true
        NumberAnimation { target: pop; property: "y"; from: pop.startY; to: pop.startY - units.gu(6); duration: 900; easing.type: Easing.OutCubic }
        SequentialAnimation {
            NumberAnimation { target: pop; property: "scale"; from: 0.5; to: 1.15; duration: 160 }
            NumberAnimation { target: pop; property: "scale"; to: 1; duration: 120 }
            PauseAnimation { duration: 320 }
            NumberAnimation { target: pop; property: "opacity"; to: 0; duration: 300 }
        }
        onFinished: pop.destroy()
    }
}
