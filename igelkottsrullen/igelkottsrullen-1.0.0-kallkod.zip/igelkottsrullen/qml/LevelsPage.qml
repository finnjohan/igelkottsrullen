// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Levels.js" as Levels

Page {
    id: page
    header: PageHeader {
        id: header
        title: root.tr("Levels")
        trailingActionBar.actions: [
            Action { iconName: "settings"; text: root.tr("Settings"); onTriggered: stack.push(Qt.resolvedUrl("SettingsPage.qml")) }
        ]
    }

    readonly property var worldColors: ({ summer: "#4E8A2E", autumn: "#B4612A", winter: "#4A86B8" })

    function timeText(sec) { return sec > 0 ? sec.toFixed(1).replace(".", root.lang === "sv" ? "," : ".") + " s" : "" }

    Flickable {
        id: flick
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: content.height + units.gu(4)
        clip: true

        Column {
            id: content
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(2)

            Repeater {
                model: Levels.worlds
                Column {
                    width: content.width
                    spacing: units.gu(1)
                    readonly property var w: modelData
                    readonly property int worldStars: {
                        var n = 0
                        for (var i = w.first; i < w.first + w.count; i++) n += root.starsFor(i)
                        return n
                    }
                    Item {
                        width: parent.width; height: units.gu(4)
                        Label {
                            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                            text: root.worldName(w.id)
                            textSize: Label.Large
                            font.weight: Font.Bold
                        }
                        Row {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            spacing: units.gu(0.5)
                            Icon { name: "starred"; color: "#F5B400"; width: units.gu(2.2); height: width; anchors.verticalCenter: parent.verticalCenter }
                            Label { anchors.verticalCenter: parent.verticalCenter; text: worldStars + " / " + w.count * 3 }
                        }
                    }
                    Grid {
                        columns: 4
                        spacing: units.gu(1)
                        Repeater {
                            model: w.count
                            AbstractButton {
                                id: btn
                                readonly property int lvl: w.first + index
                                readonly property bool open: root.unlocked(lvl)
                                width: (content.width - units.gu(3)) / 4
                                height: width * 1.25
                                enabled: open
                                onClicked: root.play(lvl)
                                Rectangle {
                                    anchors.fill: parent
                                    radius: units.gu(1.2)
                                    color: btn.open ? page.worldColors[w.id] : theme.palette.normal.base
                                    opacity: btn.pressed ? 0.75 : 1
                                }
                                Image {
                                    anchors { right: parent.right; top: parent.top; margins: units.gu(0.6) }
                                    visible: btn.open && root.starsFor(btn.lvl) > 0
                                    width: units.gu(2.4); height: width
                                    source: "../assets/hedgehog.svg"
                                    sourceSize: Qt.size(64, 64)
                                    rotation: -30
                                }
                                Column {
                                    anchors.centerIn: parent
                                    spacing: units.gu(0.4)
                                    Label {
                                        anchors.horizontalCenter: parent.horizontalCenter
                                        visible: btn.open
                                        text: btn.lvl + 1
                                        font.pixelSize: units.gu(4)
                                        font.weight: Font.Bold
                                        color: "#FFFFFF"
                                    }
                                    Icon {
                                        anchors.horizontalCenter: parent.horizontalCenter
                                        visible: !btn.open
                                        name: "lock"
                                        width: units.gu(3.5); height: width
                                        color: theme.palette.normal.backgroundSecondaryText
                                    }
                                    Row {
                                        anchors.horizontalCenter: parent.horizontalCenter
                                        visible: btn.open
                                        Repeater {
                                            model: 3
                                            Icon {
                                                width: units.gu(2); height: width
                                                name: index < root.starsFor(btn.lvl) ? "starred" : "non-starred"
                                                color: index < root.starsFor(btn.lvl) ? "#FFD54F" : "#B0FFFFFF"
                                            }
                                        }
                                    }
                                    Label {
                                        anchors.horizontalCenter: parent.horizontalCenter
                                        visible: btn.open
                                        text: root.bestFor(btn.lvl) > 0 ? page.timeText(root.bestFor(btn.lvl)) : " "
                                        textSize: Label.XSmall
                                        color: "#FFFFFF"
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("One star for reaching the den, two for picking up all the apples, and three for doing it within the star time.")
            }
        }
    }
}
