// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import QtSensors 5.12

// Läser accelerometern och räknar om till lutning −1…1 i skärmens x och y.
// calibrate() gör det aktuella greppet till "plant", så att man kan spela med
// telefonen lite lutad mot sig. Behörighet: policy group sensors (common).
Item {
    id: tilt
    property bool enabled: true
    property real sensitivity: 1.0
    // Så här många grader lutning ger full fart (vid känslighet 1)
    property real fullTiltDegrees: 18
    readonly property bool available: accel.connectedToBackend
    property real rx: 0
    property real ry: 0
    property real nx: 0
    property real ny: 0

    Accelerometer {
        id: accel
        active: tilt.probing || (tilt.enabled && Qt.application.state === Qt.ApplicationActive)
        onReadingChanged: {
            // Lätt utjämning mot skakningar
            tilt.rx = tilt.rx * 0.5 + reading.x * 0.5
            tilt.ry = tilt.ry * 0.5 + reading.y * 0.5
        }
    }
    // Starta sensorn en kort stund vid start, så att available stämmer även när
    // lutning är avstängd (QML-sensorn saknar connectToBackend)
    property bool probing: true
    Timer { interval: 1500; running: true; onTriggered: tilt.probing = false }

    function calibrate() { nx = rx; ny = ry }

    // Höger kant nedåt ger negativt x i läsningen, överkanten nedåt ger negativt y.
    // Skärmens y växer nedåt, så kulan ska rulla åt −rx och +ry.
    function value() {
        var k = sensitivity / (9.81 * Math.sin(fullTiltDegrees * Math.PI / 180))
        return [-(rx - nx) * k, (ry - ny) * k]
    }
}
