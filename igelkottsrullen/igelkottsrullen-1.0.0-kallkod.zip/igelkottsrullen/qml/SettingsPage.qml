// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import Lomiri.Components.Popups 1.3
import "I18n.js" as I18n

Page {
    id: page
    readonly property var themeValues: ["auto", "light", "dark"]
    readonly property var controlValues: ["auto", "touch"]
    readonly property var langValues: ["auto"].concat(I18n.languages.map(function (l) { return l.code }))

    header: PageHeader { id: header; title: root.tr("Settings") }

    Flickable {
        anchors { top: header.bottom; left: parent.left; right: parent.right; bottom: parent.bottom }
        contentHeight: content.height + units.gu(4)
        clip: true

        Column {
            id: content
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: units.gu(2) }
            spacing: units.gu(1.5)

            Label { text: root.tr("Control"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("Tilt the phone"), root.tr("Drag with the finger")]
                selectedIndex: Math.max(0, page.controlValues.indexOf(root.controlSetting === "tilt" ? "auto" : root.controlSetting))
                onDelegateClicked: root.setControl(page.controlValues[index])
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: tilt.available ? root.tr("You can always drag with the finger as well, even when tilting is on.")
                                     : root.tr("No tilt sensor was found, so the game uses finger control.")
            }

            // Känslighet och ett litet test där en kula visar lutningen
            Label { text: root.tr("Tilt sensitivity"); font.weight: Font.Medium; visible: tilt.available }
            Row {
                width: parent.width
                spacing: units.gu(2)
                visible: tilt.available
                Slider {
                    id: sens
                    width: parent.width - testBox.width - units.gu(2)
                    anchors.verticalCenter: parent.verticalCenter
                    minimumValue: 0.6; maximumValue: 1.6
                    value: root.sensitivity
                    live: true
                    function formatValue(v) { return Math.round(v * 100) + " %" }
                    onPressedChanged: if (!pressed) root.setSensitivity(value)
                }
                Rectangle {
                    id: testBox
                    width: units.gu(8); height: width; radius: units.gu(1)
                    color: theme.palette.normal.foreground
                    border.color: theme.palette.normal.base
                    Rectangle {
                        readonly property var t: testTimer.value
                        width: units.gu(2); height: width; radius: width / 2
                        color: "#8B5E34"
                        x: (parent.width - width) / 2 * (1 + Math.max(-1, Math.min(1, t[0])))
                        y: (parent.height - height) / 2 * (1 + Math.max(-1, Math.min(1, t[1])))
                    }
                    Timer {
                        id: testTimer
                        property var value: [0, 0]
                        interval: 50; repeat: true
                        running: tilt.available && page.visible
                        onTriggered: value = tilt.value().map(function (v) { return v * sens.value / root.sensitivity })
                    }
                    MouseArea { anchors.fill: parent; onClicked: tilt.calibrate() }
                }
            }
            Label {
                visible: tilt.available
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("The game counts down before each level and treats the way you hold the phone then as level. Tap the box to do the same here.")
            }

            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Theme"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("Automatic"), root.tr("Light (day)"), root.tr("Dark (evening)")]
                selectedIndex: Math.max(0, page.themeValues.indexOf(root.themeSetting))
                onDelegateClicked: root.setTheme(page.themeValues[index])
            }
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Language"); font.weight: Font.Medium }
            OptionSelector {
                width: parent.width
                expanded: true
                model: [root.tr("Automatic (system language)")].concat(I18n.languages.map(function (l) { return l.name }))
                selectedIndex: Math.max(0, page.langValues.indexOf(root.langSetting))
                onDelegateClicked: root.setLanguage(page.langValues[index])
            }
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Sound and screen"); font.weight: Font.Medium }
            Item {
                width: parent.width; height: units.gu(5)
                Label { anchors { left: parent.left; right: ambSwitch.left; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
                        text: root.tr("Background sounds"); wrapMode: Text.WordWrap }
                Switch { id: ambSwitch; anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                         checked: root.ambienceOn; onClicked: root.setAmbience(checked) }
            }
            Item {
                width: parent.width; height: units.gu(5)
                Label { anchors { left: parent.left; right: fxSwitch.left; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
                        text: root.tr("Sound effects"); wrapMode: Text.WordWrap }
                Switch { id: fxSwitch; anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                         checked: root.effectsOn; onClicked: root.setEffects(checked) }
            }
            Item {
                width: parent.width; height: units.gu(5)
                Label { anchors { left: parent.left; right: awakeSwitch.left; rightMargin: units.gu(1); verticalCenter: parent.verticalCenter }
                        text: root.tr("Keep the screen on while playing"); wrapMode: Text.WordWrap }
                Switch { id: awakeSwitch; anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                         checked: root.keepAwake; onClicked: root.setKeepAwake(checked) }
            }
            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("Progress"); font.weight: Font.Medium }
            Button {
                text: root.tr("Reset progress")
                onClicked: PopupUtils.open(resetDialog, page)
            }

            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("How to play"); font.weight: Font.Medium }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Tilt the phone to roll the hedgehog home to its den. If it rolls into a hole it starts over, but the apples you have picked up stay picked.")
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("In the autumn forest the mud slows you down, and in the winter forest the ice is slippery.")
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("One star for reaching the den, two for picking up all the apples, and three for doing it within the star time.")
            }

            Item { width: 1; height: units.gu(1) }
            Label { text: root.tr("About"); font.weight: Font.Medium }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Help the hedgehog find its way home through the Swedish forest. An original tilt maze game – all levels, graphics and sounds are made for this game.")
            }
            Label {
                width: parent.width
                wrapMode: Text.WordWrap
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("The background sounds come from Kottslungan by the same author.")
            }
            Label {
                textSize: Label.Small
                color: theme.palette.normal.backgroundSecondaryText
                text: root.tr("Version %1").arg(root.version) + " · © 2026 Johan Finn · GPLv3"
            }
        }
    }

    Component {
        id: resetDialog
        Dialog {
            id: dlg
            title: root.tr("Reset progress?")
            text: root.tr("All stars and best times will be deleted, and the levels will be locked again.")
            Button {
                text: root.tr("Reset")
                color: theme.palette.normal.negative
                onClicked: { root.resetProgress(); PopupUtils.close(dlg) }
            }
            Button { text: root.tr("Cancel"); onClicked: PopupUtils.close(dlg) }
        }
    }
}
