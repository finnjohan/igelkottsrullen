// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Logic.js" as Logic
import "Levels.js" as Levels

// Ritar en bana och kör spelloopen. Används både i spelet och bakom menyn.
Item {
    id: view

    property int level: 0
    property bool running: false
    property bool autoplay: false
    property bool night: false
    // Funktion som ger lutningen [ax, ay]; används när autoplay är av
    property var input: null
    property bool alignBottom: true

    // Sätts i start(): en bindning hinner inte uppdateras före onLevelChanged
    property var def: Levels.get(0)
    readonly property string world: def.world
    property var lv: Logic.parse(Levels.get(0))
    property var s: null
    property var bot: null
    property var tiles: []
    property var takenList: []

    // Det som ritas, uppdateras varje bildruta
    property real hx: 0
    property real hy: 0
    property real heading: 0
    property real hscale: 1
    property real time: 0
    property int taken: 0
    property int falls: 0
    property string phase: "play"
    readonly property int appleCount: lv.apples.length

    signal sound(string name, real volume)
    signal won()

    readonly property real ts: Math.max(1, Math.floor(Math.min(width / Logic.COLS, height / Logic.ROWS)))

    onLevelChanged: start()
    Component.onCompleted: start()

    function start() {
        def = Levels.get(level)
        lv = Logic.parse(def)
        var t = []
        for (var r = 0; r < Logic.ROWS; r++)
            for (var c = 0; c < Logic.COLS; c++)
                t.push({ c: c, r: r, wall: lv.walls[r][c], ground: lv.ground[r][c] })
        tiles = t
        s = Logic.newGame(lv)
        bot = autoplay ? Logic.newBot(lv, true) : null
        takenList = lv.apples.map(function () { return false })
        acc = 0
        lastMs = 0
        sync()
    }

    function sync() {
        hx = s.x; hy = s.y
        heading = s.heading
        time = s.time
        taken = s.taken
        falls = s.falls
        phase = s.phase
        if (s.phase === "falling") hscale = Math.max(0, 1 - s.fallT / (Logic.FALL_TIME * 0.7))
        else if (s.phase !== "won") hscale = 1
    }

    property real acc: 0
    property double lastMs: 0
    Timer {
        interval: 16
        repeat: true
        running: view.running && Qt.application.state === Qt.ApplicationActive
        onRunningChanged: view.lastMs = 0
        onTriggered: view.tick()
    }

    function tick() {
        var now = Date.now()
        var dt = lastMs ? Math.min(0.05, (now - lastMs) / 1000) : 1 / 60
        lastMs = now
        acc += dt
        var h = 1 / 120
        while (acc >= h) {
            acc -= h
            var t = [0, 0]
            if (bot) t = Logic.botTilt(bot, s)
            else if (input) t = input()
            Logic.step(s, t[0], t[1], h)
            handleEvents()
            if (s.phase === "won") { acc = 0; break }
        }
        if (s.phase === "falling") {
            // Igelkotten glider mot hålets mitt medan den krymper
            var f = Math.min(1, s.fallT / 0.25)
            s.x += (s.fallX - s.x) * f * 0.3
            s.y += (s.fallY - s.y) * f * 0.3
        }
        sync()
    }

    function handleEvents() {
        for (var i = 0; i < s.events.length; i++) {
            var e = s.events[i]
            if (e.type === "apple") {
                var l = takenList.slice(); l[e.value] = true; takenList = l
                sound("apple", 1)
                popComp.createObject(board, { x: s.apples[e.value].x * ts - ts, width: 2 * ts, startY: s.apples[e.value].y * ts - ts * 0.9,
                                              text: s.taken + "/" + s.apples.length })
            } else if (e.type === "bump") {
                sound("bump", Math.min(1, e.value / 6))
            } else if (e.type === "fall") {
                sound("fall", 1)
            } else if (e.type === "respawn") {
                if (bot) bot.idx = 0
            } else if (e.type === "win") {
                sound("win", 1)
                winAnim.start()
                won()
            }
        }
        s.events = []
    }

    Component { id: popComp; Popup { font.pixelSize: view.ts * 0.55 } }

    NumberAnimation { id: winAnim; target: view; property: "hscale"; from: 1; to: 0; duration: 600; easing.type: Easing.InBack }

    Item {
        id: board
        width: view.ts * Logic.COLS
        height: view.ts * Logic.ROWS
        x: (view.width - width) / 2
        y: view.alignBottom ? view.height - height : (view.height - height) / 2

        readonly property int tpx: Math.ceil(view.ts)

        // Underlag: mark, lera och is
        Repeater {
            model: view.tiles
            Image {
                x: modelData.c * view.ts; y: modelData.r * view.ts
                width: view.ts + 1; height: view.ts + 1
                visible: !modelData.wall
                source: modelData.ground === "mud" ? "../assets/mud.svg"
                      : modelData.ground === "ice" ? "../assets/ice.svg"
                      : "../assets/floor-" + view.world + ".svg"
                sourceSize: Qt.size(board.tpx, board.tpx)
                smooth: false
            }
        }
        // Skugga från väggarna
        Repeater {
            model: view.tiles
            Rectangle {
                visible: modelData.wall
                x: modelData.c * view.ts + view.ts * 0.12; y: modelData.r * view.ts + view.ts * 0.16
                width: view.ts; height: view.ts
                color: "#000000"
                opacity: 0.28
            }
        }
        Repeater {
            model: view.lv.holes
            Image {
                x: (modelData.x - 0.5) * view.ts; y: (modelData.y - 0.5) * view.ts
                width: view.ts; height: view.ts
                source: "../assets/hole.svg"
                sourceSize: Qt.size(board.tpx, board.tpx)
            }
        }
        Image {
            readonly property real size: view.ts * 1.3
            x: view.lv.goal.x * view.ts - size / 2; y: view.lv.goal.y * view.ts - size / 2
            width: size; height: size
            source: "../assets/goal.svg"
            sourceSize: Qt.size(Math.ceil(size), Math.ceil(size))
        }
        Repeater {
            model: view.tiles
            Image {
                visible: modelData.wall
                x: modelData.c * view.ts; y: modelData.r * view.ts
                width: view.ts + 1; height: view.ts + 1
                source: modelData.wall ? "../assets/wall-" + view.world + ".svg" : ""
                sourceSize: Qt.size(board.tpx, board.tpx)
                smooth: false
            }
        }
        Repeater {
            model: view.lv.apples
            Image {
                id: appleImg
                readonly property bool gone: view.takenList[index] === true
                readonly property real size: view.ts * 0.78
                x: modelData.x * view.ts - size / 2; y: modelData.y * view.ts - size / 2
                width: size; height: size
                source: "../assets/apple.svg"
                sourceSize: Qt.size(Math.ceil(size), Math.ceil(size))
                scale: gone ? 1.6 : 1
                opacity: gone ? 0 : 1
                Behavior on scale { NumberAnimation { duration: 250 } }
                Behavior on opacity { NumberAnimation { duration: 250 } }
                // Äpplena gungar lite
                SequentialAnimation on rotation {
                    loops: Animation.Infinite
                    running: view.running && !appleImg.gone
                    NumberAnimation { from: -6; to: 6; duration: 900 + index * 70; easing.type: Easing.InOutSine }
                    NumberAnimation { from: 6; to: -6; duration: 900 + index * 70; easing.type: Easing.InOutSine }
                }
            }
        }
        Image {
            id: hog
            readonly property real size: Logic.BALL_R * 2 * view.ts * 1.45
            x: view.hx * view.ts - size / 2
            y: view.hy * view.ts - size / 2
            width: size; height: size
            source: "../assets/hedgehog.svg"
            sourceSize: Qt.size(Math.ceil(size), Math.ceil(size))
            rotation: view.heading
            scale: view.hscale
            opacity: view.phase === "falling" ? 0.4 + 0.6 * view.hscale : 1
        }

        // Kvällsljus i mörkt tema
        Rectangle {
            anchors.fill: parent
            visible: view.night
            color: view.world === "winter" ? "#0A1E3A" : "#141A40"
            opacity: 0.38
        }
        Repeater {
            model: view.night && view.world !== "winter" ? 7 : 0
            Rectangle {
                id: fly
                width: view.ts * 0.14; height: width; radius: width / 2
                color: "#FFF59D"
                property real bx: ((index * 37) % 10 + 0.5) * view.ts
                property real by: ((index * 53) % 16 + 0.5) * view.ts
                x: bx; y: by
                SequentialAnimation on opacity {
                    loops: Animation.Infinite
                    running: view.running
                    PauseAnimation { duration: index * 300 }
                    NumberAnimation { from: 0.1; to: 1; duration: 1200 }
                    NumberAnimation { from: 1; to: 0.1; duration: 1400 }
                }
                SequentialAnimation on x {
                    loops: Animation.Infinite
                    running: view.running
                    NumberAnimation { from: fly.bx; to: fly.bx + view.ts * 0.6; duration: 3100 + index * 200; easing.type: Easing.InOutSine }
                    NumberAnimation { from: fly.bx + view.ts * 0.6; to: fly.bx; duration: 3100 + index * 200; easing.type: Easing.InOutSine }
                }
            }
        }
    }

    // Brädans läge i vyn, för pekstyrningens ring
    property alias boardItem: board
}
