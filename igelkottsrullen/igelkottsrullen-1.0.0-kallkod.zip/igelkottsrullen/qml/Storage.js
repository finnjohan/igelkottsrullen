.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
.import QtQuick.LocalStorage 2.0 as Sql

var _db = null
var _name = "igelkottsrullen"

function useDatabase(name) { _name = name; _db = null }

function db() {
    if (_db) return _db
    _db = Sql.LocalStorage.openDatabaseSync(_name, "1.0", "Igelkottsrullen", 1000000)
    _db.transaction(function (tx) {
        tx.executeSql("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
        tx.executeSql("CREATE TABLE IF NOT EXISTS progress (level INTEGER PRIMARY KEY, stars INTEGER NOT NULL, " +
                      "best_time REAL NOT NULL, apples INTEGER NOT NULL, plays INTEGER NOT NULL DEFAULT 0, ts INTEGER)")
    })
    return _db
}

function setting(key, fallback) {
    var v = fallback
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT value FROM settings WHERE key = ?", [key])
        if (rs.rows.length > 0 && rs.rows.item(0).value !== null) v = rs.rows.item(0).value
    })
    return v
}

function setSetting(key, value) {
    db().transaction(function (tx) {
        tx.executeSql("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, String(value)])
    })
}

// { nivå: { stars, best, apples, plays } } för de banor som har klarats
function progress() {
    var out = {}
    db().readTransaction(function (tx) {
        var rs = tx.executeSql("SELECT * FROM progress")
        for (var i = 0; i < rs.rows.length; i++) {
            var r = rs.rows.item(i)
            out[r.level] = { stars: r.stars, best: r.best_time, apples: r.apples, plays: r.plays }
        }
    })
    return out
}

// Sparar en klarad bana. Behåller det bästa av gammalt och nytt.
function saveResult(level, stars, time, apples, ts) {
    db().transaction(function (tx) {
        var rs = tx.executeSql("SELECT * FROM progress WHERE level = ?", [level])
        if (rs.rows.length === 0) {
            tx.executeSql("INSERT INTO progress (level, stars, best_time, apples, plays, ts) VALUES (?, ?, ?, ?, 1, ?)",
                          [level, stars, time, apples, ts || Date.now()])
        } else {
            var r = rs.rows.item(0)
            tx.executeSql("UPDATE progress SET stars = ?, best_time = ?, apples = ?, plays = plays + 1, ts = ? WHERE level = ?",
                          [Math.max(r.stars, stars), Math.min(r.best_time, time), Math.max(r.apples, apples), ts || Date.now(), level])
        }
    })
}

function resetProgress() {
    db().transaction(function (tx) { tx.executeSql("DELETE FROM progress") })
}
