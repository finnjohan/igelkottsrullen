// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import QtSystemInfo 5.0

// Stänger av skärmsläckaren medan en bana spelas och appen är aktiv.
// Kräver policy group keep-display-on (common, godkänns automatiskt).
ScreenSaver {
    screenSaverEnabled: !(root.playing && Qt.application.state === Qt.ApplicationActive)
}
