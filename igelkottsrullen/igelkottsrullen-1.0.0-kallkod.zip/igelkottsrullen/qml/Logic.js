.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later
//
// Spelreglerna för Igelkottsrullen, utan QML-beroenden (testas med node).
// Banan är ett rutnät med COLS × ROWS rutor. Enheten är en ruta, och y växer
// nedåt som på skärmen. Igelkotten är en kula som rullar när telefonen lutas.

var COLS = 10
var ROWS = 16

var BALL_R = 0.34       // igelkottens radie
var HOLE_R = 0.44       // hålets kant: här börjar kulan dras in
var FALL_R = 0.27       // så nära hålets mitt faller igelkotten ner
var APPLE_R = 0.30
var GOAL_R = 0.40       // så nära lyans mitt är banan klar
var G = 15              // acceleration vid full lutning (rutor/s²)
var MAX_SPEED = 9
var HOLE_PULL = 14
var RESTITUTION = 0.35
var FALL_TIME = 0.8     // sekunder från fall till ny start

// Dämpning per sekund för varje underlag
var DAMPING = { floor: 0.8, mud: 5.5, ice: 0.06 }

// ---- Banor ---------------------------------------------------------------
// Tecken: # vägg, . mark, o hål, a äpple, S start, G lya, ~ lera, = is
function parse(def) {
    var rows = def.map
    var lv = { walls: [], ground: [], holes: [], apples: [], start: null, goal: null }
    for (var r = 0; r < ROWS; r++) {
        var line = rows[r] || ""
        lv.walls.push([])
        lv.ground.push([])
        for (var c = 0; c < COLS; c++) {
            var ch = line.charAt(c) || "#"
            lv.walls[r].push(ch === "#")
            lv.ground[r].push(ch === "~" ? "mud" : ch === "=" ? "ice" : "floor")
            var p = { x: c + 0.5, y: r + 0.5 }
            if (ch === "o") lv.holes.push(p)
            else if (ch === "a") lv.apples.push(p)
            else if (ch === "S") lv.start = p
            else if (ch === "G") lv.goal = p
        }
    }
    // Underlaget under ett äpple, start och lya följer rutan till vänster eller höger
    // om den är lera eller is, så att is-banor inte får fläckar av gräs
    for (r = 0; r < ROWS; r++) for (c = 0; c < COLS; c++) {
        var ch2 = (rows[r] || "").charAt(c)
        if ("aSGo".indexOf(ch2) >= 0) {
            var l = c > 0 ? (rows[r] || "").charAt(c - 1) : "", rr = (rows[r] || "").charAt(c + 1)
            if (l === "=" || rr === "=") lv.ground[r][c] = "ice"
            else if (l === "~" || rr === "~") lv.ground[r][c] = "mud"
        }
    }
    return lv
}

function isWall(lv, c, r) {
    if (c < 0 || r < 0 || c >= COLS || r >= ROWS) return true
    return lv.walls[r][c]
}

function groundAt(lv, x, y) {
    var c = Math.floor(x), r = Math.floor(y)
    if (c < 0 || r < 0 || c >= COLS || r >= ROWS) return "floor"
    return lv.ground[r][c]
}

// ---- Spelets tillstånd ---------------------------------------------------
function newGame(lv) {
    var s = {
        lv: lv,
        x: lv.start.x, y: lv.start.y, vx: 0, vy: 0,
        spin: 0,                 // grader, för att rita rullningen
        heading: 90,
        apples: lv.apples.map(function (a) { return { x: a.x, y: a.y, taken: false } }),
        taken: 0, falls: 0, time: 0,
        phase: "play",           // play, falling, won
        fallT: 0, fallX: 0, fallY: 0,
        events: []
    }
    return s
}

function emit(s, type, v) { s.events.push({ type: type, value: v || 0 }) }

function clampTilt(ax, ay) {
    var m = Math.sqrt(ax * ax + ay * ay)
    if (m > 1) { ax /= m; ay /= m }
    return [ax, ay]
}

// Ett fast tidssteg. ax och ay är lutningen, −1…1 i x och y.
function step(s, ax, ay, dt) {
    if (s.phase === "won") return
    s.time += dt
    if (s.phase === "falling") {
        s.fallT += dt
        if (s.fallT >= FALL_TIME) {
            s.phase = "play"
            s.x = s.lv.start.x; s.y = s.lv.start.y
            s.vx = 0; s.vy = 0
            emit(s, "respawn")
        }
        return
    }
    var t = clampTilt(ax, ay)
    s.vx += t[0] * G * dt
    s.vy += t[1] * G * dt

    // Hålen drar i kulan när den rullar över kanten
    var holes = s.lv.holes
    for (var i = 0; i < holes.length; i++) {
        var dx = holes[i].x - s.x, dy = holes[i].y - s.y
        var d = Math.sqrt(dx * dx + dy * dy)
        if (d < FALL_R) {
            s.phase = "falling"
            s.fallT = 0
            s.fallX = holes[i].x; s.fallY = holes[i].y
            s.falls++
            emit(s, "fall")
            return
        }
        if (d < HOLE_R) {
            var k = HOLE_PULL * (1 - d / HOLE_R) * dt / d
            s.vx += dx * k
            s.vy += dy * k
        }
    }

    var damp = Math.exp(-DAMPING[groundAt(s.lv, s.x, s.y)] * dt)
    s.vx *= damp; s.vy *= damp
    var sp = Math.sqrt(s.vx * s.vx + s.vy * s.vy)
    if (sp > MAX_SPEED) { s.vx *= MAX_SPEED / sp; s.vy *= MAX_SPEED / sp; sp = MAX_SPEED }

    s.x += s.vx * dt
    s.y += s.vy * dt
    collide(s)

    s.spin = (s.spin + sp * dt / BALL_R * 180 / Math.PI) % 360
    if (sp > 0.3) s.heading = Math.atan2(s.vy, s.vx) * 180 / Math.PI

    for (i = 0; i < s.apples.length; i++) {
        var a = s.apples[i]
        if (a.taken) continue
        var ex = a.x - s.x, ey = a.y - s.y
        if (ex * ex + ey * ey < (BALL_R + APPLE_R * 0.8) * (BALL_R + APPLE_R * 0.8)) {
            a.taken = true
            s.taken++
            emit(s, "apple", i)
        }
    }

    var gx = s.lv.goal.x - s.x, gy = s.lv.goal.y - s.y
    if (gx * gx + gy * gy < GOAL_R * GOAL_R) {
        s.phase = "won"
        s.x = s.lv.goal.x; s.y = s.lv.goal.y
        s.vx = 0; s.vy = 0
        emit(s, "win")
    }
}

// Kulan mot väggrutorna runt omkring. Studsen ger en händelse med farten.
function collide(s) {
    var R = BALL_R
    var bump = 0
    for (var pass = 0; pass < 2; pass++) {
        var c0 = Math.floor(s.x - R), c1 = Math.floor(s.x + R)
        var r0 = Math.floor(s.y - R), r1 = Math.floor(s.y + R)
        for (var r = r0; r <= r1; r++) for (var c = c0; c <= c1; c++) {
            if (!isWall(s.lv, c, r)) continue
            var px = Math.max(c, Math.min(s.x, c + 1))
            var py = Math.max(r, Math.min(s.y, r + 1))
            var dx = s.x - px, dy = s.y - py
            var d2 = dx * dx + dy * dy
            if (d2 >= R * R) continue
            var d = Math.sqrt(d2)
            var nx, ny
            if (d < 1e-6) {
                // Mitten hamnade i väggen: knuffa ut åt det håll där det är närmast
                var opts = [[s.x - c, -1, 0], [c + 1 - s.x, 1, 0], [s.y - r, 0, -1], [r + 1 - s.y, 0, 1]]
                opts.sort(function (a, b) { return a[0] - b[0] })
                nx = opts[0][1]; ny = opts[0][2]; d = -opts[0][0]
            } else {
                nx = dx / d; ny = dy / d
            }
            s.x += nx * (R - d)
            s.y += ny * (R - d)
            var vn = s.vx * nx + s.vy * ny
            if (vn < 0) {
                s.vx -= (1 + RESTITUTION) * vn * nx
                s.vy -= (1 + RESTITUTION) * vn * ny
                bump = Math.max(bump, -vn)
            }
        }
    }
    if (bump > 1.6) emit(s, "bump", bump)
}

// ---- Stjärnor ------------------------------------------------------------
// ★ banan klar, ★★ alla äpplen, ★★★ alla äpplen inom stjärntiden
function stars(def, lv, taken, time) {
    var all = taken >= lv.apples.length
    return 1 + (all ? 1 : 0) + (all && time <= def.par ? 1 : 0)
}

// ---- Datorspelare --------------------------------------------------------
// Planerar en väg på ett finare rutnät (RES punkter per ruta) som håller
// avstånd till väggar och hål, och styr sedan lutningen mot vägen.
var RES = 4

function planGrid(lv) {
    var W = COLS * RES + 1, H = ROWS * RES + 1
    var free = new Array(W * H)
    var cost = new Array(W * H)
    var wallClear = BALL_R + 0.06, holeClear = HOLE_R + 0.10
    for (var j = 0; j < H; j++) for (var i = 0; i < W; i++) {
        var x = i / RES, y = j / RES
        var ok = true
        for (var r = Math.floor(y - 1); r <= Math.floor(y + 1) && ok; r++)
            for (var c = Math.floor(x - 1); c <= Math.floor(x + 1) && ok; c++) {
                if (!isWall(lv, c, r)) continue
                var px = Math.max(c, Math.min(x, c + 1)), py = Math.max(r, Math.min(y, r + 1))
                if ((x - px) * (x - px) + (y - py) * (y - py) < wallClear * wallClear) ok = false
            }
        var near = 0
        for (var h = 0; h < lv.holes.length && ok; h++) {
            var hd = Math.sqrt((lv.holes[h].x - x) * (lv.holes[h].x - x) + (lv.holes[h].y - y) * (lv.holes[h].y - y))
            if (hd < holeClear) ok = false
            else if (hd < holeClear + 0.4) near = 1
        }
        free[j * W + i] = ok
        var g = groundAt(lv, x, y)
        cost[j * W + i] = (g === "mud" ? 2.2 : g === "ice" ? 1.4 : 1) + near * 0.6
    }
    return { W: W, H: H, free: free, cost: cost }
}

function nearestFree(grid, x, y) {
    var bi = -1, bd = 1e9
    for (var j = 0; j < grid.H; j++) for (var i = 0; i < grid.W; i++) {
        if (!grid.free[j * grid.W + i]) continue
        var d = (i / RES - x) * (i / RES - x) + (j / RES - y) * (j / RES - y)
        if (d < bd) { bd = d; bi = j * grid.W + i }
    }
    return bi
}

// Dijkstra från en punkt; ger avstånd och föregångare
function dijkstra(grid, from) {
    var N = grid.W * grid.H
    var dist = new Float64Array(N), prev = new Int32Array(N), done = new Uint8Array(N)
    for (var k = 0; k < N; k++) { dist[k] = 1e18; prev[k] = -1 }
    dist[from] = 0
    var heap = [[0, from]]
    function push(item) {
        heap.push(item)
        var i = heap.length - 1
        while (i > 0) {
            var p = (i - 1) >> 1
            if (heap[p][0] <= heap[i][0]) break
            var t = heap[p]; heap[p] = heap[i]; heap[i] = t; i = p
        }
    }
    function pop() {
        var top = heap[0], last = heap.pop()
        if (heap.length > 0) {
            heap[0] = last
            var i = 0
            for (;;) {
                var l = 2 * i + 1, r = l + 1, m = i
                if (l < heap.length && heap[l][0] < heap[m][0]) m = l
                if (r < heap.length && heap[r][0] < heap[m][0]) m = r
                if (m === i) break
                var t = heap[m]; heap[m] = heap[i]; heap[i] = t; i = m
            }
        }
        return top
    }
    var dirs = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]]
    while (heap.length) {
        var it = pop(), u = it[1]
        if (done[u]) continue
        done[u] = 1
        var ui = u % grid.W, uj = (u - ui) / grid.W
        for (var d = 0; d < 8; d++) {
            var vi = ui + dirs[d][0], vj = uj + dirs[d][1]
            if (vi < 0 || vj < 0 || vi >= grid.W || vj >= grid.H) continue
            var v = vj * grid.W + vi
            if (!grid.free[v] || done[v]) continue
            // Diagonaler bara om båda grannarna är fria
            if (dirs[d][0] && dirs[d][1] && (!grid.free[uj * grid.W + vi] || !grid.free[vj * grid.W + ui])) continue
            var nd = dist[u] + dirs[d][2] * (grid.cost[u] + grid.cost[v]) / 2
            if (nd < dist[v]) { dist[v] = nd; prev[v] = u; push([nd, v]) }
        }
    }
    return { dist: dist, prev: prev }
}

function tracePath(grid, dj, to) {
    var out = []
    for (var v = to; v >= 0; v = dj.prev[v]) {
        var i = v % grid.W
        out.push({ x: i / RES, y: (v - i) / grid.W / RES })
    }
    return out.reverse()
}

// Väljer ordningen på äpplena som ger kortast väg (alla ordningar, högst 5 äpplen)
function planRoute(lv, wantApples) {
    var grid = planGrid(lv)
    var pts = [lv.start]
    if (wantApples) pts = pts.concat(lv.apples)
    pts.push(lv.goal)
    var nodes = pts.map(function (p) { return nearestFree(grid, p.x, p.y) })
    var djs = nodes.map(function (n) { return dijkstra(grid, n) })
    var n = pts.length
    var mids = []
    for (var i = 1; i < n - 1; i++) mids.push(i)
    var best = null, bestLen = 1e18
    function permute(arr, k) {
        if (k === arr.length) {
            var order = [0].concat(arr).concat([n - 1])
            var len = 0
            for (var q = 0; q + 1 < order.length; q++) len += djs[order[q]].dist[nodes[order[q + 1]]]
            if (len < bestLen) { bestLen = len; best = order.slice() }
            return
        }
        for (var m = k; m < arr.length; m++) {
            var t = arr[k]; arr[k] = arr[m]; arr[m] = t
            permute(arr, k + 1)
            t = arr[k]; arr[k] = arr[m]; arr[m] = t
        }
    }
    permute(mids, 0)
    if (!best || bestLen >= 1e17) return null
    var path = []
    for (var q = 0; q + 1 < best.length; q++) {
        var seg = tracePath(grid, djs[best[q]], nodes[best[q + 1]])
        // Sista punkten i varje del är själva målet (äpplet eller lyan)
        seg.push({ x: pts[best[q + 1]].x, y: pts[best[q + 1]].y, target: true })
        path = path.concat(q === 0 ? seg : seg.slice(1))
    }
    return { path: path, length: bestLen, grid: grid }
}

function newBot(lv, wantApples) {
    var route = planRoute(lv, wantApples !== false)
    return { route: route, idx: 0, speed: 3.2 }
}

// Ger lutningen [ax, ay] för nästa steg
function botTilt(bot, s) {
    if (!bot.route || s.phase !== "play") return [0, 0]
    var p = bot.route.path
    // Hoppa fram längs vägen till den punkt som är närmast kulan (men aldrig bakåt)
    // men inte förbi nästa mål som inte är nått än
    var limit = bot.idx
    while (limit + 1 < p.length && !p[limit].target) limit++
    if (p[limit].target && (p[limit].x - s.x) * (p[limit].x - s.x) + (p[limit].y - s.y) * (p[limit].y - s.y) < 0.09) {
        limit++
        while (limit + 1 < p.length && !p[limit].target) limit++
    }
    var bestI = bot.idx, bestD = 1e9
    for (var i = bot.idx; i <= Math.min(limit, p.length - 1, bot.idx + 24); i++) {
        var d = (p[i].x - s.x) * (p[i].x - s.x) + (p[i].y - s.y) * (p[i].y - s.y)
        if (d <= bestD) { bestD = d; bestI = i }
    }
    bot.idx = bestI
    // Sikta en bit framåt, men inte förbi nästa mål
    var look = bot.idx
    var ahead = 0
    while (look + 1 < p.length && ahead < 0.9) {
        if (p[look].target && look > bot.idx &&
            (p[look].x - s.x) * (p[look].x - s.x) + (p[look].y - s.y) * (p[look].y - s.y) > 0.09) break
        ahead += Math.sqrt((p[look + 1].x - p[look].x) * (p[look + 1].x - p[look].x) + (p[look + 1].y - p[look].y) * (p[look + 1].y - p[look].y))
        look++
    }
    var tx = p[look].x - s.x, ty = p[look].y - s.y
    var tl = Math.sqrt(tx * tx + ty * ty) || 1
    var g = groundAt(s.lv, s.x, s.y)
    var speed = bot.speed * (g === "ice" ? 0.7 : 1)
    // Sakta in när vägen svänger eller nära hål
    var nearHole = 9
    for (var h = 0; h < s.lv.holes.length; h++) {
        var hx = s.lv.holes[h].x - s.x, hy = s.lv.holes[h].y - s.y
        nearHole = Math.min(nearHole, Math.sqrt(hx * hx + hy * hy))
    }
    if (nearHole < 1.3) speed *= 0.65
    speed = Math.min(speed, tl * 3 + 0.6)
    var wx = tx / tl * speed, wy = ty / tl * speed
    var kp = g === "mud" ? 1.5 : 0.9
    var ax = (wx - s.vx) * kp, ay = (wy - s.vy) * kp
    // I leran räcker det inte att bromsa: håll alltid lite lutning framåt
    return clampTilt(ax, ay)
}

// Kör en hel bana med datorspelaren. Ger tid, fall och om den klarades.
function simulate(def, opts) {
    opts = opts || {}
    var lv = parse(def)
    var s = newGame(lv)
    var bot = newBot(lv, opts.apples !== false)
    if (!bot.route) return { won: false, reason: "ingen väg" }
    var dt = 1 / 120, maxT = opts.maxTime || 120
    while (s.phase !== "won" && s.time < maxT) {
        var t = botTilt(bot, s)
        step(s, t[0], t[1], dt)
        if (s.events.length) {
            for (var e = 0; e < s.events.length; e++) if (s.events[e].type === "respawn") bot.idx = 0
            s.events = []
        }
        if (opts.maxFalls !== undefined && s.falls > opts.maxFalls) break
    }
    return { won: s.phase === "won", time: s.time, falls: s.falls, taken: s.taken, apples: lv.apples.length, length: bot.route.length }
}
