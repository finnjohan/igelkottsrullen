.pragma library
// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

var languages = [
    { code: "en", name: "English" },
    { code: "sv", name: "Svenska" }
]

var sv = {
    // Meny
    "Tilt the phone and roll the hedgehog home": "Luta telefonen och rulla hem igelkotten",
    "Play": "Spela",
    "Play level %1": "Spela bana %1",
    "Levels": "Banor",
    "Touch control is on": "Pekstyrning är påslagen",
    "No tilt sensor found – drag your finger to play": "Ingen lutningssensor hittades – dra med fingret för att spela",

    // Världar och banor
    "Summer forest": "Sommarskogen",
    "Autumn forest": "Höstskogen",
    "Winter forest": "Vinterskogen",
    "First roll": "Första rullen",
    "Mind the holes": "Akta hålen",
    "Hedge maze": "Häcklabyrinten",
    "Mole hills": "Mullvadsbacken",
    "Muddy path": "Lerstigen",
    "Puddle jumping": "Pölhoppet",
    "Fallen leaves": "Lövhögen",
    "Mushroom ring": "Svampringen",
    "Frozen pond": "Frusna dammen",
    "Slippery slope": "Halkbacken",
    "Icicle alley": "Istappsgränd",
    "Snowstorm": "Snöstormen",
    "One star for reaching the den, two for picking up all the apples, and three for doing it within the star time.":
        "En stjärna när igelkotten når lyan, två när du har plockat alla äpplen och tre när du dessutom klarar stjärntiden.",

    // Spelet
    "Hold the phone the way you want to play": "Håll telefonen som du vill spela",
    "Drag your finger to roll the hedgehog": "Dra med fingret för att rulla igelkotten",
    "Then tilt it to roll the hedgehog home to its den. Pick up the apples and keep away from the holes!":
        "Luta den sedan för att rulla hem igelkotten till lyan. Plocka äpplena och akta dig för hålen!",
    "Roll the hedgehog home to its den. Pick up the apples and keep away from the holes!":
        "Rulla hem igelkotten till lyan. Plocka äpplena och akta dig för hålen!",
    "Paused": "Paus",
    "Continue": "Fortsätt",
    "Restart level": "Börja om banan",
    "Quit": "Avsluta",
    "Home in the den!": "Hemma i lyan!",
    "time": "tid",
    "apples": "äpplen",
    "falls": "fall",
    "New best time!": "Ny bästa tid!",
    "All apples, and within the star time!": "Alla äpplen, och inom stjärntiden!",
    "All apples! Be faster than %1 s for the third star.": "Alla äpplen! Var snabbare än %1 s för den tredje stjärnan.",
    "Pick up all the apples for another star.": "Plocka alla äpplen för en stjärna till.",
    "Back": "Tillbaka",
    "Again": "Igen",
    "Next": "Nästa",

    // Inställningar
    "Settings": "Inställningar",
    "Control": "Styrning",
    "Tilt the phone": "Luta telefonen",
    "Drag with the finger": "Dra med fingret",
    "You can always drag with the finger as well, even when tilting is on.":
        "Du kan alltid dra med fingret också, även när lutning är påslagen.",
    "No tilt sensor was found, so the game uses finger control.":
        "Ingen lutningssensor hittades, så spelet styrs med fingret.",
    "Tilt sensitivity": "Känslighet för lutning",
    "The game counts down before each level and treats the way you hold the phone then as level. Tap the box to do the same here.":
        "Spelet räknar ner före varje bana, och så som du håller telefonen då räknas som plant. Tryck på rutan för att göra samma sak här.",
    "Theme": "Tema",
    "Automatic": "Automatiskt",
    "Light (day)": "Ljust (dag)",
    "Dark (evening)": "Mörkt (kväll)",
    "Language": "Språk",
    "Automatic (system language)": "Automatiskt (systemets språk)",
    "Sound and screen": "Ljud och skärm",
    "Background sounds": "Bakgrundsljud",
    "Sound effects": "Ljudeffekter",
    "Keep the screen on while playing": "Håll skärmen tänd medan du spelar",
    "Progress": "Framsteg",
    "Reset progress": "Nollställ framsteg",
    "Reset progress?": "Nollställa framstegen?",
    "All stars and best times will be deleted, and the levels will be locked again.":
        "Alla stjärnor och bästa tider tas bort, och banorna låses igen.",
    "Reset": "Nollställ",
    "Cancel": "Avbryt",
    "How to play": "Så spelar du",
    "Tilt the phone to roll the hedgehog home to its den. If it rolls into a hole it starts over, but the apples you have picked up stay picked.":
        "Luta telefonen för att rulla hem igelkotten till lyan. Rullar den ner i ett hål får den börja om, men äpplena du redan har plockat behåller du.",
    "In the autumn forest the mud slows you down, and in the winter forest the ice is slippery.":
        "I höstskogen bromsar leran, och i vinterskogen är isen hal.",
    "About": "Om",
    "Help the hedgehog find its way home through the Swedish forest. An original tilt maze game – all levels, graphics and sounds are made for this game.":
        "Hjälp igelkotten att hitta hem genom den svenska skogen. Ett eget labyrintspel där man lutar telefonen – alla banor, all grafik och alla ljud är gjorda för det här spelet.",
    "The background sounds come from Kottslungan by the same author.": "Bakgrundsljuden kommer från Kottslungan av samma upphovsperson.",
    "Version %1": "Version %1"
}

var tables = { sv: sv }

function systemLanguage(localeName) {
    return (localeName || "en").substring(0, 2) === "sv" ? "sv" : "en"
}

function tr(s, lang) {
    var t = tables[lang]
    return (t && t[s] !== undefined) ? t[s] : s
}
