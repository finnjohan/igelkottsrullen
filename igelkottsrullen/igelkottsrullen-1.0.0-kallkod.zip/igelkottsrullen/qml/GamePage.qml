// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Logic.js" as Logic
import "Levels.js" as Levels

Page {
    id: page
    // Ingen rubrikrad: banan ska fylla skärmen
    header: Item { height: 0; visible: false }

    property int level: 0
    readonly property string world: game.world
    property bool paused: false
    property bool showResult: false
    property int countdown: 3
    property int resultStars: 0
    property real resultTime: 0
    property bool newBest: false
    property bool showHelp: root.starsFor(0) === 0 && level === 0

    readonly property color textColor: "#FFFFFF"
    readonly property color outline: "#3A2A10"
    readonly property bool active: stack.currentPage === page

    function restart() {
        showResult = false
        paused = false
        game.start()
        startCountdown()
    }

    function startCountdown() {
        if (root.autoplay) { countdown = 0; return }
        countdown = 3
        countTimer.restart()
        root.playSound("tick")
    }

    function clock(sec) {
        var s = Math.floor(sec)
        var tenths = Math.floor((sec - s) * 10)
        return Math.floor(s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60) + "." + tenths
    }

    onActiveChanged: root.playing = active && countdown === 0 && !paused && !showResult
    onPausedChanged: root.playing = active && countdown === 0 && !paused && !showResult
    onShowResultChanged: root.playing = active && countdown === 0 && !paused && !showResult
    onCountdownChanged: root.playing = active && countdown === 0 && !paused && !showResult
    Component.onDestruction: root.playing = false
    Component.onCompleted: startCountdown()

    Timer {
        id: countTimer
        interval: 700
        repeat: true
        running: false
        onTriggered: {
            if (page.paused) return
            // Greppet medan man räknar ner blir "plant"
            tilt.calibrate()
            page.countdown--
            if (page.countdown > 0) root.playSound("tick")
            else { root.playSound("go"); stop() }
        }
    }

    Rectangle {
        anchors.fill: parent
        color: game.world === "winter" ? "#5E7A94" : game.world === "autumn" ? "#4A3A22" : "#2F5A26"
    }

    GameView {
        id: game
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; top: parent.top; topMargin: units.gu(7) }
        level: page.level
        autoplay: root.autoplay
        night: root.isDark
        running: page.active && !page.paused && !page.showResult && page.countdown === 0 && phase !== "won"
        input: page.readInput
        onSound: root.playSound(name, volume)
        onWon: resultTimer.start()
    }

    // Lutningen, eller fingret om det är nere (fungerar alltid, och är enda sättet utan sensor)
    function readInput() {
        if (touch.pressed) return touch.value()
        if (root.useTilt) return tilt.value()
        return [0, 0]
    }

    Timer {
        id: resultTimer
        interval: 750
        onTriggered: {
            var stars = Logic.stars(game.def, game.lv, game.taken, game.time)
            page.resultStars = stars
            page.resultTime = game.time
            var old = root.bestFor(page.level)
            page.newBest = old > 0 && game.time < old
            root.saveResult(page.level, stars, game.time, game.taken)
            page.showResult = true
        }
    }

    // Paus när appen inte är aktiv
    Connections {
        target: Qt.application
        function onStateChanged() { if (Qt.application.state !== Qt.ApplicationActive && !page.showResult && game.phase !== "won") page.paused = true }
    }

    // ---- Pekstyrning: dra från där fingret sätts ner -----------------------
    MouseArea {
        id: touch
        anchors.fill: parent
        enabled: !page.paused && !page.showResult
        property real ox: 0
        property real oy: 0
        property real cx: 0
        property real cy: 0
        readonly property real reach: units.gu(7)
        onPressed: { ox = cx = mouse.x; oy = cy = mouse.y }
        onPositionChanged: { cx = mouse.x; cy = mouse.y }
        function value() { return [(cx - ox) / reach, (cy - oy) / reach] }
    }
    Item {
        visible: touch.pressed
        x: touch.ox; y: touch.oy
        Rectangle {
            width: touch.reach * 2; height: width; radius: width / 2
            x: -width / 2; y: -height / 2
            color: "#30FFFFFF"
            border.color: "#80FFFFFF"; border.width: units.dp(2)
        }
        Rectangle {
            readonly property real dx: Math.max(-touch.reach, Math.min(touch.reach, touch.cx - touch.ox))
            readonly property real dy: Math.max(-touch.reach, Math.min(touch.reach, touch.cy - touch.oy))
            width: units.gu(4); height: width; radius: width / 2
            x: dx - width / 2; y: dy - height / 2
            color: "#C0FFFFFF"
        }
    }

    // ---- Överst: bana, äpplen, tid, paus -----------------------------------
    Item {
        id: hud
        anchors { left: parent.left; right: parent.right; top: parent.top }
        height: units.gu(7)
        Column {
            anchors { left: parent.left; leftMargin: units.gu(1.5); verticalCenter: parent.verticalCenter }
            Label {
                text: (page.level + 1) + ". " + root.levelName(page.level)
                font.weight: Font.Bold
                color: page.textColor
                style: Text.Outline; styleColor: page.outline
            }
            Row {
                spacing: units.gu(1.5)
                Row {
                    spacing: units.gu(0.4)
                    Image {
                        anchors.verticalCenter: parent.verticalCenter
                        source: "../assets/apple.svg"
                        width: units.gu(2.6); height: width
                        sourceSize: Qt.size(64, 64)
                    }
                    Label {
                        anchors.verticalCenter: parent.verticalCenter
                        text: game.taken + "/" + game.appleCount
                        textSize: Label.Large
                        font.weight: Font.Bold
                        color: page.textColor
                        style: Text.Outline; styleColor: page.outline
                    }
                }
                Label {
                    anchors.verticalCenter: parent.verticalCenter
                    text: page.clock(game.time)
                    textSize: Label.Large
                    font.weight: Font.Bold
                    // Grön så länge stjärntiden går att nå
                    color: game.time <= game.def.par ? "#C5F7A0" : page.textColor
                    style: Text.Outline; styleColor: page.outline
                }
            }
        }
        RoundButton {
            anchors { right: parent.right; rightMargin: units.gu(1.5); verticalCenter: parent.verticalCenter }
            iconName: "media-playback-pause"
            visible: !page.showResult
            onClicked: page.paused = true
        }
    }

    // ---- Nedräkning och hjälp ---------------------------------------------
    Column {
        anchors.centerIn: game
        spacing: units.gu(2)
        visible: page.countdown > 0 && !page.paused
        Label {
            anchors.horizontalCenter: parent.horizontalCenter
            text: page.countdown
            font.pixelSize: units.gu(12)
            font.weight: Font.Bold
            color: page.textColor
            style: Text.Outline; styleColor: page.outline
        }
        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: Math.min(page.width - units.gu(4), units.gu(38))
            height: helpCol.height + units.gu(2.5)
            radius: units.gu(1.5)
            color: "#B0000000"
            Column {
                id: helpCol
                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: units.gu(1.5) }
                spacing: units.gu(0.6)
                Label {
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    text: root.useTilt ? root.tr("Hold the phone the way you want to play") : root.tr("Drag your finger to roll the hedgehog")
                    color: "#FFFFFF"
                    font.weight: Font.Bold
                }
                Label {
                    width: parent.width
                    visible: page.showHelp
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    text: root.useTilt ? root.tr("Then tilt it to roll the hedgehog home to its den. Pick up the apples and keep away from the holes!")
                                       : root.tr("Roll the hedgehog home to its den. Pick up the apples and keep away from the holes!")
                    color: "#FFFFFF"
                }
            }
        }
    }

    // ---- Paus ------------------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: page.paused && !page.showResult
        color: "#90000000"
        MouseArea { anchors.fill: parent }
        Column {
            anchors.centerIn: parent
            spacing: units.gu(2)
            Label {
                anchors.horizontalCenter: parent.horizontalCenter
                text: root.tr("Paused")
                font.pixelSize: units.gu(4); font.weight: Font.Bold
                color: "#FFFFFF"
            }
            Button {
                anchors.horizontalCenter: parent.horizontalCenter
                width: units.gu(24)
                text: root.tr("Continue")
                color: "#E8862A"
                onClicked: { page.paused = false; if (page.countdown > 0) page.startCountdown() }
            }
            Button {
                anchors.horizontalCenter: parent.horizontalCenter
                width: units.gu(24)
                text: root.tr("Restart level")
                onClicked: page.restart()
            }
            Button {
                anchors.horizontalCenter: parent.horizontalCenter
                width: units.gu(24)
                text: root.tr("Quit")
                onClicked: stack.pop()
            }
        }
    }

    // ---- Resultat --------------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        visible: page.showResult
        color: "#80000000"
        MouseArea { anchors.fill: parent }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(parent.width - units.gu(4), units.gu(40))
            height: resultCol.height + units.gu(5)
            radius: units.gu(2)
            color: theme.palette.normal.background
            border.color: theme.palette.normal.base

            Column {
                id: resultCol
                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: units.gu(2.5) }
                spacing: units.gu(1.5)
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: root.tr("Home in the den!")
                    textSize: Label.Large
                    font.weight: Font.Bold
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: units.gu(1)
                    Repeater {
                        model: 3
                        Icon {
                            id: starIcon
                            width: units.gu(6); height: width
                            name: index < page.resultStars ? "starred" : "non-starred"
                            color: index < page.resultStars ? "#F5B400" : theme.palette.normal.base
                            scale: 0
                            // Stjärnorna dyker upp en i taget
                            SequentialAnimation {
                                running: page.showResult
                                PropertyAction { target: starIcon; property: "scale"; value: 0 }
                                PauseAnimation { duration: 200 + index * 280 }
                                ScriptAction { script: if (index < page.resultStars) root.playSound("star") }
                                NumberAnimation { target: starIcon; property: "scale"; from: 0; to: 1; duration: 260; easing.type: Easing.OutBack }
                            }
                        }
                    }
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: units.gu(3)
                    Column {
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: page.clock(page.resultTime); font.weight: Font.Bold; textSize: Label.Large }
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: root.tr("time"); textSize: Label.Small; color: theme.palette.normal.backgroundSecondaryText }
                    }
                    Column {
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: game.taken + "/" + game.appleCount; font.weight: Font.Bold; textSize: Label.Large }
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: root.tr("apples"); textSize: Label.Small; color: theme.palette.normal.backgroundSecondaryText }
                    }
                    Column {
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: game.falls; font.weight: Font.Bold; textSize: Label.Large }
                        Label { anchors.horizontalCenter: parent.horizontalCenter; text: root.tr("falls"); textSize: Label.Small; color: theme.palette.normal.backgroundSecondaryText }
                    }
                }
                Label {
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    text: page.newBest ? root.tr("New best time!")
                        : page.resultStars === 3 ? root.tr("All apples, and within the star time!")
                        : page.resultStars === 2 ? root.tr("All apples! Be faster than %1 s for the third star.").arg(game.def.par)
                        : root.tr("Pick up all the apples for another star.")
                    color: page.newBest ? theme.palette.normal.positive : theme.palette.normal.backgroundSecondaryText
                    font.weight: page.newBest ? Font.Bold : Font.Normal
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: units.gu(1)
                    Button {
                        width: units.gu(10)
                        text: root.tr("Back")
                        onClicked: stack.pop()
                    }
                    Button {
                        width: units.gu(10)
                        text: root.tr("Again")
                        onClicked: page.restart()
                    }
                    Button {
                        width: units.gu(10)
                        visible: page.level + 1 < root.levelCount
                        text: root.tr("Next")
                        color: "#E8862A"
                        onClicked: root.replay(page.level + 1)
                    }
                }
            }
        }
    }
}
