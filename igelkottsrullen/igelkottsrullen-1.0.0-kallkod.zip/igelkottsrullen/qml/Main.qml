// SPDX-FileCopyrightText: 2026 Johan Finn
// SPDX-License-Identifier: GPL-3.0-or-later

import QtQuick 2.12
import Lomiri.Components 1.3
import "Storage.js" as Storage
import "I18n.js" as I18n
import "Levels.js" as Levels

MainView {
    id: root
    objectName: "mainView"
    applicationName: "igelkottsrullen.johanfinn"
    automaticOrientation: false

    width: units.gu(argValue("width") !== "" ? parseInt(argValue("width"), 10) : 45)
    height: units.gu(argValue("height") !== "" ? parseInt(argValue("height"), 10) : 80)

    readonly property string version: "1.0.0"
    readonly property bool isDark: theme.palette.normal.background.hslLightness < 0.5

    // ---- Kommandoradsflaggor för test och skärmdumpar ---------------------
    // --demo (egen databas med några klarade banor)  --lang=sv|en  --theme=light|dark
    // --page=levels|settings|game  --level=<n> (1–12)  --autoplay (datorspelaren rullar)
    // --control=tilt|touch  --width=<gu>  --height=<gu>  --mute
    function argValue(name) {
        var args = Qt.application.arguments
        for (var i = 0; i < args.length; i++) {
            if (args[i] === "--" + name) return "1"
            if (args[i].indexOf("--" + name + "=") === 0) return args[i].substring(name.length + 3)
        }
        return ""
    }
    readonly property bool demo: argValue("demo") !== ""
    readonly property bool autoplay: argValue("autoplay") !== ""

    // ---- Inställningar --------------------------------------------------
    property string themeSetting: "auto"
    property string langSetting: "auto"
    property string controlSetting: "auto"      // auto, tilt, touch
    property real sensitivity: 1.0              // 0.6–1.6
    property bool ambienceOn: true
    property bool effectsOn: true
    property bool keepAwake: true
    readonly property string lang: langSetting === "auto" ? I18n.systemLanguage(Qt.locale().name) : langSetting
    // Lutning används om sensorn finns och inte är avstängd
    readonly property bool useTilt: controlSetting !== "touch" && tilt.available

    function tr(s) { return I18n.tr(s, lang) }

    function setTheme(value) { themeSetting = value; Storage.setSetting("theme", value); applyTheme() }
    function setLanguage(value) { langSetting = value; Storage.setSetting("language", value) }
    function setControl(value) { controlSetting = value; Storage.setSetting("control", value) }
    function setSensitivity(value) { sensitivity = value; Storage.setSetting("sensitivity", value.toFixed(2)) }
    function setAmbience(on) { ambienceOn = on; Storage.setSetting("ambience", on ? "1" : "0") }
    function setEffects(on) { effectsOn = on; Storage.setSetting("effects", on ? "1" : "0") }
    function setKeepAwake(on) { keepAwake = on; Storage.setSetting("keepAwake", on ? "1" : "0") }
    function playSound(name, volume) { sounds.play(name, volume) }

    function applyTheme() {
        if (themeSetting === "dark") theme.name = "Lomiri.Components.Themes.SuruDark"
        else if (themeSetting === "light") theme.name = "Lomiri.Components.Themes.Ambiance"
        else theme.name = ""
    }

    // ---- Framsteg -------------------------------------------------------
    property var progress: ({})
    readonly property int levelCount: Levels.count()
    function reloadProgress() { progress = Storage.progress() }
    function starsFor(i) { return progress[i] ? progress[i].stars : 0 }
    function bestFor(i) { return progress[i] ? progress[i].best : 0 }
    function unlocked(i) { return i === 0 || starsFor(i - 1) > 0 }
    function totalStars() {
        var n = 0
        for (var i = 0; i < levelCount; i++) n += starsFor(i)
        return n
    }
    // Första banan som inte är klarad, annars den sista
    function nextLevel() {
        for (var i = 0; i < levelCount; i++) if (starsFor(i) === 0) return i
        return levelCount - 1
    }
    function saveResult(level, stars, time, apples) { Storage.saveResult(level, stars, time, apples); reloadProgress() }
    function resetProgress() { Storage.resetProgress(); reloadProgress() }
    function worldName(id) {
        return id === "autumn" ? tr("Autumn forest") : id === "winter" ? tr("Winter forest") : tr("Summer forest")
    }
    function levelName(i) { return tr(Levels.get(i).name) }

    function play(level) { stack.push(Qt.resolvedUrl("GamePage.qml"), { level: level }) }

    // Spelsidan visar sig själv; en ny bana ersätter den gamla i stacken
    function replay(level) {
        stack.pop()
        play(level)
    }

    Component.onCompleted: {
        if (demo) {
            Storage.useDatabase("igelkottsrullen-demo")
            Storage.resetProgress()
            var demoRes = [[3, 14.2, 3], [3, 16.8, 3], [2, 27.5, 3], [3, 11.9, 3], [2, 18.4, 3], [1, 21.0, 1]]
            for (var i = 0; i < demoRes.length; i++) Storage.saveResult(i, demoRes[i][0], demoRes[i][1], demoRes[i][2])
        }
        langSetting = argValue("lang") !== "" ? argValue("lang") : Storage.setting("language", "auto")
        themeSetting = argValue("theme") !== "" ? argValue("theme") : Storage.setting("theme", "auto")
        controlSetting = argValue("control") !== "" ? argValue("control") : Storage.setting("control", "auto")
        sensitivity = parseFloat(Storage.setting("sensitivity", "1.0")) || 1.0
        keepAwake = Storage.setting("keepAwake", "1") === "1"
        applyTheme()
        var mute = argValue("mute") !== ""
        ambienceOn = !mute && Storage.setting("ambience", "1") === "1"
        effectsOn = !mute && Storage.setting("effects", "1") === "1"
        reloadProgress()
        stack.push(Qt.resolvedUrl("MenuPage.qml"))
        var page = argValue("page")
        if (page === "levels") stack.push(Qt.resolvedUrl("LevelsPage.qml"))
        else if (page === "settings") stack.push(Qt.resolvedUrl("SettingsPage.qml"))
        else if (page === "game") play(argValue("level") !== "" ? Math.max(0, Math.min(levelCount - 1, parseInt(argValue("level"), 10) - 1)) : nextLevel())
    }

    PageStack { id: stack }

    Tilt {
        id: tilt
        sensitivity: root.sensitivity
        enabled: root.controlSetting !== "touch"
    }

    Sounds {
        id: sounds
        ambienceOn: root.ambienceOn
        effectsOn: root.effectsOn
        world: stack.currentPage && stack.currentPage.world === "winter" ? "winter" : "forest"
    }

    // Håll skärmen tänd medan man spelar (behörigheten keep-display-on).
    // Laddas via Loader: saknas modulen QtSystemInfo fortsätter appen utan den.
    Loader {
        active: root.keepAwake
        source: "KeepAwake.qml"
        onStatusChanged: if (status === Loader.Error) console.log("KeepAwake: QtSystemInfo saknas, skärmen kan släckas")
    }
    property bool playing: false
}
